/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 tv_tester tv_tester.png
 * Time-stamp: Tuesday 03/06/2018, 00:21:51
 *
 * Image Information
 * -----------------
 * tv_tester.png 240@160
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TV_TESTER_H
#define TV_TESTER_H

extern unsigned short tv_tester[38400];
#define TV_TESTER_SIZE 76800
#define TV_TESTER_LENGTH 38400
#define TV_TESTER_WIDTH 240
#define TV_TESTER_HEIGHT 160

#endif
