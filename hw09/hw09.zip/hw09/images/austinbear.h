/*
 * Exported with nin10kit v1.7
 * Time-stamp: Friday 10/26/2018, 17:21:23
 *
 * Image Information
 * -----------------
 * /Users/cgokmen/Downloads/austinbear.jpg 150@94
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AUSTINBEAR_H
#define AUSTINBEAR_H

extern unsigned short austinbear[14100];
#define AUSTINBEAR_SIZE 28200
#define AUSTINBEAR_LENGTH 14100
#define AUSTINBEAR_WIDTH 150
#define AUSTINBEAR_HEIGHT 94

#endif
