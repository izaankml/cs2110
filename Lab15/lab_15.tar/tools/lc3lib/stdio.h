


extern void printf(const char *format, ...);
extern void scanf(const char *format, ...);
