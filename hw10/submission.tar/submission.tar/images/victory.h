/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 victory victory.png 
 * Time-stamp: Wednesday 11/21/2018, 04:00:36
 * 
 * Image Information
 * -----------------
 * victory.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VICTORY_H
#define VICTORY_H

extern const unsigned short victory[38400];
#define VICTORY_SIZE 76800
#define VICTORY_LENGTH 38400
#define VICTORY_WIDTH 240
#define VICTORY_HEIGHT 160

#endif

