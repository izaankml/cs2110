/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=80x60 izaan izaan.png 
 * Time-stamp: Wednesday 11/21/2018, 04:32:59
 * 
 * Image Information
 * -----------------
 * izaan.png 80@60
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef IZAAN_H
#define IZAAN_H

extern const unsigned short izaan[4800];
#define IZAAN_SIZE 9600
#define IZAAN_LENGTH 4800
#define IZAAN_WIDTH 80
#define IZAAN_HEIGHT 60

#endif

