Welcome to the World's Hardest Game: Deadline Before Break Edition by Izaan Kamal!

Begin by pressing A (z for the most part on your keyboard).

Your objective is to move your player around using the arrow keys and to reach the Purple Happy Fun Zone! Careful to avoid the Red Angry Death Boxes, as they will murder you in your face. If you reach the PHFZ, you WIN! You can celebrate by hitting Select to play again! You can hit select to play again at any point really, but dont tell people. If you run out of lives, you die. It's alright tho, as you can just hit select and try again!

Game is best enjoyed with earphones connected to two seperate audio sources. The left earbud should start playing In Da Club by 50 Cent, and then after 20 seconds the right earbud should chime in with the Pokemon Advanced Battle theme song.**

**Not tested, but if you do it let me know how it turns out.