/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 puppy2 puppy2.jpg 
 * Time-stamp: Saturday 11/03/2018, 21:36:09
 * 
 * Image Information
 * -----------------
 * puppy2.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PUPPY2_H
#define PUPPY2_H

extern const unsigned short puppy2[38400];
#define PUPPY2_SIZE 76800
#define PUPPY2_LENGTH 38400
#define PUPPY2_WIDTH 240
#define PUPPY2_HEIGHT 160

#endif

