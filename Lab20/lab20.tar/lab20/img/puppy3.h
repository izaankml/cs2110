/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 puppy3 puppy3.jpg 
 * Time-stamp: Saturday 11/03/2018, 21:36:13
 * 
 * Image Information
 * -----------------
 * puppy3.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PUPPY3_H
#define PUPPY3_H

extern const unsigned short puppy3[38400];
#define PUPPY3_SIZE 76800
#define PUPPY3_LENGTH 38400
#define PUPPY3_WIDTH 240
#define PUPPY3_HEIGHT 160

#endif

